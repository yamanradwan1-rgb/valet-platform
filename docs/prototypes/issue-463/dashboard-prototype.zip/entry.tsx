import React,{useState} from 'react';
import {createRoot} from 'react-dom/client';
import {CustomerFeedbackInsights as Original} from './apps/dashboard/src/features/intelligence/customer-feedback-insights';
import {CustomerFeedbackInsights as Proposed} from './apps/dashboard/src/features/intelligence/customer-feedback-insights-proposed';
import {CustomerFeedbackSummary} from './apps/dashboard/src/features/intelligence/customer-feedback-summary';
import {customerFeedbackCopy} from './apps/dashboard/src/features/intelligence/customer-feedback-copy';
import styles from './apps/dashboard/src/features/intelligence/customer-feedback.module.css';
import './prototype.css';
const params=new URLSearchParams(location.search);
const ids=['82070C92EF0E','933DC477387C','40FCA2994129','D9122683CB78'];
const comments=['Excellent service. The staff were professional and my car was ready quickly.',null,'خدمة ممتازة وسرعة في استلام السيارة.\nشكراً لفريق العمل.',null];
const data={averageRating:5,participationRate:0.8,ratedVisits:4,eligibleCompletedVisits:5,distribution:{five:4,four:0,three:0,two:0,one:0},recentRatings:ids.map((id,i)=>({visitReference:'VISIT-'+id,authorizedLocationLabel:'VAYLET Test — Irbid',rating:5,completedAt:'2026-11-'+['13','13','12','07'][i]+'T12:00:00Z',ratedAt:'2026-11-'+['13','13','12','07'][i]+'T12:00:00Z',locationTimezone:'Asia/Amman',comment:comments[i]}))};
function App(){
 const [locale,setLocale]=useState<'ar'|'en'>(params.get('lang')==='ar'?'ar':'en');
 const [theme,setTheme]=useState(params.get('theme')==='light'?'light':'dark');
 const [original,setOriginal]=useState(params.get('original')==='1');
 const [full,setFull]=useState(params.get('full')==='1');
 document.documentElement.lang=locale;document.documentElement.dir=locale==='ar'?'rtl':'ltr';document.documentElement.dataset.theme=theme;
 const t=customerFeedbackCopy(locale);const Insights=original?Original:Proposed;
 return <><div className="preview-toolbar" dir="ltr"><span>VAYLET · ISSUE 463 · MOCK DATA</span><button onClick={()=>setOriginal(!original)}>{original?'Original':'Proposed'}</button><button onClick={()=>setLocale(locale==='en'?'ar':'en')}>{locale.toUpperCase()}</button><button onClick={()=>setTheme(theme==='dark'?'light':'dark')}>{theme}</button><button onClick={()=>setFull(!full)}>{full?'Full section':'Recent ratings only'}</button><a href="http://127.0.0.1:3463/">Guest prototype</a></div><main className={full?'preview-full':'preview-single'}><section className={styles.section}>{full&&<><div className={styles.sectionHeader}><div><h2>{t.heading}</h2><p>VAYLET Test — Irbid · 2026-11-01 – 2026-11-26</p></div></div><CustomerFeedbackSummary data={data as any} locale={locale}/></>}<Insights data={data as any} locale={locale}/>{full&&<p className={styles.note}>{t.cohort}</p>}</section></main></>;
}
createRoot(document.getElementById('root')!).render(<App/>);