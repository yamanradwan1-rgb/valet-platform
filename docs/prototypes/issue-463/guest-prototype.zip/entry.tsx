import React,{useState} from 'react';
import {createRoot} from 'react-dom/client';
import {LocaleProvider,useTranslation} from './apps/customer/src/i18n/locale-provider';
import {ThemeProvider} from './apps/customer/src/theme/theme-provider';
import {AppShell} from './apps/customer/src/components/layout/app-shell';
import {OverlayMoreMenu} from './apps/customer/src/features/deferred/overlay-more-menu';
import {GuestLiveRating} from './apps/customer/src/features/rating/guest-live-rating';
import {GuestCommentsRating} from './apps/customer/src/features/rating/guest-comments-rating';
import {ScreenCompleted} from './apps/customer/src/features/session/screen-completed';
import {useTheme} from './apps/customer/src/theme/use-theme';
import './apps/customer/src/app/globals.css';
import './prototype.css';
const params=new URLSearchParams(location.search);
const visitId='prototype-only';
const session={valetSessionId:visitId,state:'COMPLETED',vehicle:{make:'Toyota',model:'Camry',color:'Black'}};
let fail=false;
const client={submitRating:async(rating:number)=>{await new Promise(r=>setTimeout(r,950));if(fail)throw new Error('Mock failure');return {valetSessionId:visitId,rating};},loadSession:async()=>session};
function Preview(){
 const {locale,setLocale,t}=useTranslation();const {theme,setTheme}=useTheme();
 const [original,setOriginal]=useState(params.get('original')==='1');
 const [rating,setRating]=useState(true);const [more,setMore]=useState(false);const [key,setKey]=useState(0);const [failure,setFailure]=useState(false);
 const restart=()=>{setRating(true);setKey(k=>k+1)};
 return <><div className="prototype-toolbar" dir="ltr"><span>ISSUE 463 · MOCK</span><button onClick={()=>{setOriginal(!original);restart()}}>{original?'Original':'Proposed'}</button><button onClick={()=>setLocale(locale==='ar'?'en':'ar')}>{locale.toUpperCase()}</button><button onClick={()=>setTheme(theme==='dark'?'light':'dark')}>{theme}</button><button aria-pressed={failure} onClick={()=>{fail=!failure;setFailure(!failure)}}>{failure?'Failure':'Success'}</button><button onClick={restart}>Reset</button></div><AppShell onMore={()=>setMore(true)}>{rating?(original?<GuestLiveRating key={key} client={client as any} visitId={visitId} canRate onBack={()=>setRating(false)}/>:<GuestCommentsRating key={key} client={client as any} visitId={visitId} canRate onBack={()=>setRating(false)}/>):<ScreenCompleted session={session as any} onRateExperience={restart}/>}<OverlayMoreMenu open={more} onClose={()=>setMore(false)} client={null}/></AppShell></>;
}
if(params.get('lang'))localStorage.setItem('vaylet_guest_locale',params.get('lang')!);
else if(!localStorage.getItem('vaylet_guest_locale'))localStorage.setItem('vaylet_guest_locale','ar');
if(params.get('theme'))localStorage.setItem('vaylet_guest_theme',params.get('theme')!);
createRoot(document.getElementById('root')!).render(<LocaleProvider><ThemeProvider><Preview/></ThemeProvider></LocaleProvider>);